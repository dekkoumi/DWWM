public class document

    {

    private String[] authos
        
    {
     private date;

        public String getAuthors(String_Authors)

        public date getDate(date_date)
            {

public class Book
{
    private String title;

    public String getTitle(String_Title)
}
                
    
                    
public class EMail {    
                        
     private String subject;

    private String[]

    public String getSubject(String_subject)

    public String getTo(String_To)


                    }

            
                }
            }
    }

    }
